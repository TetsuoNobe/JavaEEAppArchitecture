/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.time.LocalDate;

/**
 *
 * @author TNOBE
 */
public class DateConverter {
    public static LocalDate  convertStringToLocalDate(String  yyyymmdd) {
           LocalDate ld = null;
           ld = LocalDate.of(Integer.parseInt(yyyymmdd.substring(0, 4)),
                            Integer.parseInt(yyyymmdd.substring(4, 6)),
                            Integer.parseInt(yyyymmdd.substring(6, 8))        
           
           );
           return ld;
        
    }
    
   
    
}
