/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.MemberDAO;
import dao.RentalDAO;
import entity.Member;
import entity.Rental;
import java.sql.SQLException;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

/**
 *
 * @author TNOBE
 */
@Dependent
public class RentalService {
    
    @Inject
    MemberDAO  memberDao;
    
    @Inject
    RentalDAO  rentalDao;
    
    public  Member createMember(Member  member) throws SQLException {
        return memberDao.create(member);
    }
    
    public int getNewMemberId() throws SQLException {
        return memberDao.getId();
    }
    
    public Member getMemberById(String memberId) throws SQLException {
        return memberDao.findById(memberId);
    }

    public Rental  getRentalById(int  rentalId) throws SQLException {
         return rentalDao.findById(rentalId);
    }
    
    
    public Rental  processRental(Rental  rental) throws SQLException {
         return rentalDao.create(rental);
    }
    
    public void  processReturn(int rentalId) throws SQLException {
          rentalDao.updateRetuenCode(rentalId,"9");
    }
    
    public int getNewRentalId() throws SQLException {
        return rentalDao.getId();
    }
   
    
}
