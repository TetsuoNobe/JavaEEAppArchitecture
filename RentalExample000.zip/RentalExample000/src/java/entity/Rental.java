/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author TNOBE
 */
public class Rental {
    private int       rentalId;
    private Member    member;
    private LocalDate rentalDate;
    private LocalDate returnDate;
    private List<RentalItem>  rentalItemList;

    public Rental() {
    }

    public Rental(int rentalId, Member member, LocalDate rentalDate, LocalDate returnDate, List<RentalItem> rentalItem) {
        this.rentalId = rentalId;
        this.member = member;
        this.rentalDate = rentalDate;
        this.returnDate = returnDate;
        this.rentalItemList = rentalItem;
    }

    public int getRentalId() {
        return rentalId;
    }

    public void setRentalId(int rentalId) {
        this.rentalId = rentalId;
    }

    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public LocalDate getRentalDate() {
        return rentalDate;
    }

    public void setRentalDate(LocalDate rentalDate) {
        this.rentalDate = rentalDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public List<RentalItem> getRentalItemList() {
        return rentalItemList;
    }

    public void setRentalItemList(List<RentalItem> rentalItem) {
        this.rentalItemList = rentalItem;
    }
    
    
}
