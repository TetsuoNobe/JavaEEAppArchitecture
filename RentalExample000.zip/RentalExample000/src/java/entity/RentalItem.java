/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author TNOBE
 */
public class RentalItem {
     private String  itemCode;
     private int  serialId;
     private String  returnCd;

    public RentalItem() {
    }

    public RentalItem(String itemCode, int serialId, String returnCd) {
        this.itemCode = itemCode;
        this.serialId = serialId;
        this.returnCd = returnCd;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public int getSerialId() {
        return serialId;
    }

    public void setSerialId(int serialId) {
        this.serialId = serialId;
    }

    public String getReturnCd() {
        return returnCd;
    }

    public void setReturnCd(String returnCd) {
        this.returnCd = returnCd;
    }
     
     
}
