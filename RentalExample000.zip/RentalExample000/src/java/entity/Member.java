/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author TNOBE
 */
public class Member implements Serializable {
    
    private int        memberId;
    private String     name;
    private String     address;
    private String     telno;
    private LocalDate  registerDate;

    public Member(int memberId,String name, String address, String telno, LocalDate registerDate) {
        this.memberId = memberId;
        this.name = name;
        this.address = address;
        this.telno = telno;
        this.registerDate = registerDate;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTelno() {
        return telno;
    }

    public void setTelno(String telno) {
        this.telno = telno;
    }

    public LocalDate getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(LocalDate registerDate) {
        this.registerDate = registerDate;
    }
    
    public String getFormatedRegisterDate() {
        String ymd = "" + registerDate.getYear() + registerDate.getMonthValue() + registerDate.getDayOfMonth();
        return ymd;
    }
    
    public String getFormatedExpireDate() {
        LocalDate  expireDate =  this.registerDate.plusYears(1);
        String ymd = "" + expireDate.getYear() + expireDate.getMonthValue() + expireDate.getDayOfMonth();
        return ymd;
    } 
    
    
}
