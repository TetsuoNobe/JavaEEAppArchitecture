
conn hr/hr;
DROP SEQUENCE member_id_seq;
DROP SEQUENCE rental_id_seq;
DROP TABLE members;
DROP TABLE rental;
DROP TABLE rentalitems 
CREATE SEQUENCE  member_id_seq;
CREATE SEQUENCE  rental_id_seq;
CREATE TABLE     members (
       member_id        number(8) primary key,
       member_name      varchar2(100),
       member_address   varchar2(200),
       member_telno     varchar2(50),
       register_date    date
);

CREATE TABLE rental (
   rental_id     number(8) primary key,
   member_id     number(8),
   rental_date   date,
   return_date   date
);

CREATE TABLE rentalitems (
   rental_id     number(8) ,
   item_code     varchar2(10),
   serial_id     number(3),
   return_code   varchar2(3) default '1'
);

ALTER TABLE rentalitems ADD PRIMARY KEY (rental_id,item_code,serial_id);




