/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Member;
import entity.Rental;
import entity.RentalItem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.Dependent;
import javax.sql.DataSource;

/**
 *
 * @author TNOBE
 */
@Dependent
public class RentalDAO {

    @Resource(name = "jdbc/oracle")
    DataSource ds;

    // RENTALテーブルを主キー検索する
    public Rental findById(int rentalId) throws SQLException {

        // RENTALテーブルをRENTAL_IDの条件で検索するSQL文
        String selectRentalSQL = "SELECT R.RENTAL_ID  RENTAL_ID "
                + "     ,    M.MEMBER_ID      MEMBER_ID"
                + "     ,    M.MEMBER_NAME    MEMBER_NAME"
                + "     ,    M.MEMBER_ADDRESS MEMBER_ADDRESS"
                + "     ,    M.MEMBER_TELNO   MEMBER_TELNO"
                + "     ,    M.REGISTER_DATE  REGISTER_DATE"
                + "     ,    R.RENTAL_DATE    RENTAL_DATE"
                + "     ,    R.RETURN_DATE    RETURN_DATE"
                + "  FROM RENTAL R, MEMBERS M"
                + "  WHERE R.MEMBER_ID = M.MEMBER_ID "
                + "    AND R.RENTAL_ID = ?";

        String selectRentalItemsSQL = "SELECT RENTAL_ID "
                + "     ,    ITEM_CODE"
                + "     ,    SERIAL_ID"
                + "     ,    RETURN_CODE"
                + "  FROM RENTALITEMS "
                + "  WHERE RENTAL_ID = ? ";

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        Rental rental = null;
        try (Connection con = ds.getConnection();
                PreparedStatement psRental = con.prepareStatement(selectRentalSQL);
                PreparedStatement psItems = con.prepareStatement(selectRentalItemsSQL)) {

            // プレース・ホルダに値を設定
            psRental.setInt(1, rentalId);
            psItems.setInt(1, rentalId);

            try (ResultSet rsRental = psRental.executeQuery()) {
                // 検索結果が存在しない場合、NULLを返す
                if (!rsRental.next()) {
                    return null;
                }
                try (ResultSet rsItems = psItems.executeQuery()) {
                    // Rentalオブジェクトを生成
                    rental = createRental(rsRental, rsItems);
                }
            }
        }
        // Rentalを返す
        return rental;
    }

    public Rental create(Rental rental) throws SQLException {

        // RENTALテーブルにデータを追加するSQL文
        String insertRentalSQL = "INSERT INTO RENTAL"
                + "          ( RENTAL_ID "
                + "          , MEMBER_ID "
                + "          , RENTAL_DATE "
                + "          , RETURN_DATE "
                + " ) VALUES (?, ?, ?, ?)";

        String insertRentalItemsSQL = "INSERT INTO RENTALITEMS"
                + "          ( RENTAL_ID "
                + "          , ITEM_CODE "
                + "          , SERIAL_ID "
                + "          , RETURN_CODE "
                + " ) VALUES (?, ?, ?, ?)";
        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement psRental = con.prepareStatement(insertRentalSQL);
                PreparedStatement psItems = con.prepareStatement(insertRentalItemsSQL)) {
            // AutoCommitを無効化
            con.setAutoCommit(false);
            // プレース・ホルダに値を設定
            psRental.setInt(1, rental.getRentalId());
            psRental.setInt(2, rental.getMember().getMemberId());
            java.sql.Date date = java.sql.Date.valueOf(rental.getRentalDate());
            psRental.setDate(3, date);
            date = java.sql.Date.valueOf(rental.getReturnDate());
            psRental.setDate(4, date);
            //
            // SQL文を実行
            psRental.executeUpdate();
            //
            for (RentalItem item : rental.getRentalItemList()) {
                psItems.setInt(1, rental.getRentalId());
                psItems.setString(2, item.getItemCode());
                psItems.setInt(3, item.getSerialId());
                psItems.setString(4, item.getReturnCd());
                psItems.executeUpdate();
            }
            //
            con.commit();
            // 実行結果を返す
            return rental;
        }
    }

    //RETAILITEMSテーブルの返却コードを更新する
    public void updateRetuenCode(int rentalId, String returnCode) throws SQLException {
        // RENTALテーブルをRENTAL_IDの条件で検索するSQL文
        String updateReturnCodeSQL = "UPDATE RENTALITEMS SET "
                + "  RETURN_CODE = ?  "
                + "  WHERE RENTAL_ID= ? ";

        try (Connection con = ds.getConnection();
                PreparedStatement psReturnCode = con.prepareStatement(updateReturnCodeSQL);) {
            psReturnCode.setString(1, returnCode);
            psReturnCode.setInt(2, rentalId);
            psReturnCode.executeUpdate();
        }

    }

    // 新規貸出IDを採番する
    public int getId() throws SQLException {

        // 新規番号を採番するSQL文
        String sql = "SELECT RENTAL_ID_SEQ.NEXTVAL FROM DUAL";

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            rs.next();
            int newid = rs.getInt(1);

            // 実行結果を返す
            return newid;
        }
    }

    // ResultSetからMemberオブジェクトを生成する
    private Rental createRental(ResultSet rsRental, ResultSet rsItems) throws SQLException {
        //
        java.sql.Date sqlRenDate = rsRental.getDate("RENTAL_DATE");
        java.sql.Date sqlRetDate = rsRental.getDate("RETURN_DATE");
        java.sql.Date sqlRegDate = rsRental.getDate("REGISTER_DATE");
        //
        Member member = new Member(rsRental.getInt("MEMBER_ID"),
                rsRental.getString("MEMBER_NAME"),
                rsRental.getString("MEMBER_ADDRESS"),
                rsRental.getString("MEMBER_TELNO"),
                sqlRegDate.toLocalDate()
        );
        //
        List<RentalItem> list = new ArrayList<>();
        while (rsItems.next()) {
            RentalItem item = new RentalItem(rsItems.getString("ITEM_CODE"), rsItems.getInt("SERIAL_ID"), rsItems.getString("RETURN_CODE"));
            list.add(item);
        }
        
        Rental rental = new Rental(rsRental.getInt("RENTAL_ID"),
                member,
                sqlRenDate.toLocalDate(),
                sqlRetDate.toLocalDate(),
                list
        );

        return rental;
    }

}
