/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Member;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.annotation.Resource;
import javax.enterprise.context.Dependent;
import javax.sql.DataSource;

/**
 *
 * @author TNOBE
 */
@Dependent
public class MemberDAO {
    @Resource(name = "jdbc/oracle")
    DataSource ds;


    // MEMBERSテーブルを主キー検索する
    public Member findById(String memberId) throws SQLException {

        // MEMBERテーブルをMEMBER_IDの条件で検索するSQL文
        String sql = "SELECT MEMBER_ID "
                + "     , MEMBER_NAME "
                + "     , MEMBER_ADDRESS "
                + "     , MEMBER_TELNO "
                + "     , REGISTER_DATE "
                + "  FROM MEMBERS"
                + "  WHERE MEMBER_ID = ?";

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            // プレース・ホルダに値を設定
            ps.setString(1, memberId);

            try (ResultSet rs = ps.executeQuery()) {
                // 検索結果が存在しない場合、NULLを返す
                if (!rs.next()) {
                    return null;
                }

                // Memberオブジェクトを生成
                Member member = createMember(rs);

                // Memberを返す
                return member;
            }
        }
    }
    
     public Member create(Member member) throws SQLException {
        
        // MEMBERSテーブルにデータを追加するSQL文
        String sql = "INSERT INTO MEMBERS"
                + "          ( MEMBER_ID "
                + "          , MEMBER_NAME "
                + "          , MEMBER_ADDRESS "
                + "          , MEMBER_TELNO "
                + "          ,  REGISTER_DATE "
                + " ) VALUES (?, ?, ?, ?, ?)";

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            // プレース・ホルダに値を設定
            ps.setInt(1, member.getMemberId());
            ps.setString(2, member.getName());
            ps.setString(3, member.getAddress());
            ps.setString(4, member.getTelno());
            java.sql.Date rdate = java.sql.Date.valueOf(member.getRegisterDate());
            ps.setDate(5, rdate);

            // SQL文を実行
            ps.executeUpdate();
            
            // 実行結果を返す
            return member;
        }
    }

  
    // 新規会員IDを採番する
    public int getId() throws SQLException {

        // 新規番号を採番するSQL文
        String sql = "SELECT MEMBER_ID_SEQ.NEXTVAL FROM DUAL";
 
        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
                rs.next();
                int newid = rs.getInt(1);

            // 実行結果を返す
            return newid;
        }
    }

  


    // ResultSetからMemberオブジェクトを生成する
    private Member createMember(ResultSet rs) throws SQLException {
        java.sql.Date sqlDate = rs.getDate("REGISTER_DATE");
        Member member = new Member(rs.getInt("MEMBER_ID"),
                                   rs.getString("MEMBER_NAME"),
                                   rs.getString("MEMBER_ADDRESS"),
                                   rs.getString("MEMBER_TELNO"),
                                   sqlDate.toLocalDate()
                             );

        return member;
    }
    
    
}
