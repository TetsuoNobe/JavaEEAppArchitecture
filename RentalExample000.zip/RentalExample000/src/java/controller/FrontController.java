/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Member;
import entity.Rental;
import entity.RentalItem;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import service.RentalService;
import util.DateConverter;

/**
 *
 * @author TNOBE
 */
@WebServlet(name = "FrontController", urlPatterns = {"/controller"})
public class FrontController extends HttpServlet {

    @Inject
    RentalService service;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 文字コードを設定
        request.setCharacterEncoding("UTF-8");
        //  リクエストを処理
        String nextView = doAction(request, response);
        // Viewのディスパッチ
        request.getRequestDispatcher(nextView).forward(request, response);
    }

    private String doAction(HttpServletRequest request, HttpServletResponse response) {
        String nextView = null;
        String action = request.getParameter("action");
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String telno = request.getParameter("telno");
        String ymd = request.getParameter("registerDate");
        HttpSession session =  request.getSession(true);
        try {
            switch (action) {
                case "index":
                    session.invalidate();
                    nextView = "/index.jsp";
                    break;
                case "showMemberForm":
                    nextView = "/MemberForm.jsp";
                    break;
                case "confirmNewMember":
                    int newid = service.getNewMemberId();
                    Member newMember = new Member(newid, name, address, telno, LocalDate.now());
                    request.setAttribute("newmember", newMember);
                    nextView = "/confirmNewMember.jsp";
                    break;
                case "createMember":
                    LocalDate regDate = DateConverter.convertStringToLocalDate(ymd);
                    Member member = new Member(Integer.parseInt(id), name, address, telno, regDate);
                    Member newmember = service.createMember(member);
                    nextView = "/index.jsp";
                    break;
                case "showRentalForm":
                    String memberId = request.getParameter("memberId");
                    Member rentalmember = service.getMemberById(memberId);
                    request.setAttribute("rentalmember", rentalmember);
                    request.setAttribute("rentaldate", LocalDate.now());
                    nextView = "/RentalForm.jsp";
                    break;
                case "confirmNewRental":
                    Rental newRental = getRental(request);
                    session.setAttribute("newrental", newRental);
                    nextView = "/confirmNewRental.jsp";
                    break;
                case "createRental":
                    session =  request.getSession();
                    Rental createRental = (Rental) session.getAttribute("newrental");
                    service.processRental(createRental);
                    session.removeAttribute("newrental");
                    nextView = "/index.jsp";
                    break;
                case "confirmReturn":
                    String sconretRentalId = request.getParameter("rentalId");
                    int  conretRentalId = Integer.parseInt(sconretRentalId);
                    Rental conretRental = service.getRentalById(conretRentalId);
                    request.setAttribute("returnRental", conretRental);
                    nextView = "/confirmReturn.jsp";
                    break;
                case "return":
                     String sretRentalId = request.getParameter("rentalId");
                     int  retRentalId = Integer.parseInt(sretRentalId);
                    service.processReturn(retRentalId);
                    nextView = "/index.jsp";
                    break;
                default:

            }

        } catch (SQLException sqlex) {
            sqlex.printStackTrace();
            request.setAttribute("action", request.getParameter("action"));
            request.setAttribute("errorMessage", sqlex.getMessage());
            session.invalidate();
            return "/error.jsp";
        } catch (Exception ex) {
            ex.printStackTrace();
            request.setAttribute("action", request.getParameter("action"));
            request.setAttribute("errorMessage", ex.getMessage());
            session.invalidate();
            return "/error.jsp";
        }
        return nextView;
    }

    private Rental getRental(HttpServletRequest req) throws SQLException {
        String rentalMemberId = req.getParameter("memberId");
        String rentalYMD = req.getParameter("rentalYMD");
        String sdays = req.getParameter("days");
        String[] itemcds = req.getParameterValues("itemcds");
        String[] serialids = req.getParameterValues("serialids");
        //
        int newrentalid = service.getNewRentalId();
        Member member =  service.getMemberById(rentalMemberId);
        //
        LocalDate rentalDate = DateConverter.convertStringToLocalDate(rentalYMD);
        int days = Integer.parseInt(sdays);
        LocalDate returnDate = rentalDate.plusDays(days);
        
        //
        int idx = 0;
        List<RentalItem> list = new ArrayList<>();
        for (String itemcd : itemcds) {
            if (itemcd != null && itemcd.length() > 0) {
              int serialid = Integer.parseInt(serialids[idx]);
              RentalItem item = new RentalItem(itemcd,serialid,"1");
              list.add(item);
              idx++;
            }
        }
        //
        Rental rental = new Rental(newrentalid,member,rentalDate,returnDate,list);
        
        return rental;

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
