/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.command;

import java.sql.SQLException;
import java.util.List;
import example.controller.RequestContext;
import example.controller.ResponseContext;
import example.entity.Customer;
import example.service.CustomerService;

/**
 *
 * @author TNOBE
 */
public class FindByNameCommand extends Command {

    private CustomerService service;

    public FindByNameCommand(CustomerService service) {
        this.service = service;
    }

    @Override
    protected ResponseContext processRequest(RequestContext requestContext) throws SQLException {
        List<Customer> customerList = service.findByName(requestContext.getName());
        ResponseContext responseContext = new ResponseContext();
        responseContext.setRequestContext(requestContext);
        if (customerList.isEmpty()) {
            responseContext.setErrorMessage("該当顧客なし");
            responseContext.setNextPage("/error.jsp");
        } else {
            responseContext.setCustomerList(customerList);
            responseContext.setNextPage("/list.jsp");
        }

        return responseContext;
    }

}
