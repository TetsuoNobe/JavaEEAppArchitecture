/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.command;

import java.sql.SQLException;
import example.controller.RequestContext;
import example.controller.ResponseContext;
import example.entity.Customer;
import example.service.CustomerService;

/**
 *
 * @author TNOBE
 */
public class UpdateFormCommand  extends Command{
    
     private CustomerService  service;


    public UpdateFormCommand(CustomerService service) {
        this.service = service;
    }

    @Override
    protected ResponseContext processRequest(RequestContext requestContext) throws SQLException {
               Customer customer = service.find(requestContext.getId());
               ResponseContext responseContext = new ResponseContext();
               responseContext.setRequestContext(requestContext);
               if (customer != null) {
                  responseContext.setCustomer(customer);
                  responseContext.setNextPage("/updateForm.jsp");
               }else{
                  responseContext.setErrorMessage("該当顧客なし"); 
                  responseContext.setNextPage("/error.jsp"); 
               } 
                  
               return responseContext;
    }
    
}
