/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.command;

import java.sql.SQLException;
import example.controller.RequestContext;
import example.controller.ResponseContext;
import example.entity.Customer;
import example.service.CustomerService;

/**
 *
 * @author TNOBE
 */
public class CreateCommand  extends Command {
    
     private CustomerService  service;


    public CreateCommand(CustomerService service) {
        this.service = service;
    }

    @Override
    protected ResponseContext processRequest(RequestContext requestContext) throws SQLException {
           ResponseContext responseContext = new ResponseContext();
           if (!isInteger(requestContext.getId())) {
               responseContext.setRequestContext(requestContext);
               responseContext.setErrorMessage("IDには数値を指定してください。");
               responseContext.setNextPage("/error.jsp");
               return responseContext;
           }
           Customer customer = new Customer(requestContext.getId(),requestContext.getName(),requestContext.getAddress(),requestContext.getTelno());
           boolean result = service.create(customer);         
           responseContext.setCustomer(customer);
           responseContext.setSuccess(result);
           responseContext.setNextPage("/index.jsp");
           return responseContext;
    }
    
    private  boolean isInteger(String strNum) {
		try {
			Integer.parseUnsignedInt(strNum);
			return true;
		} catch(NumberFormatException e) {
			return false;
		}
	}
    
}
