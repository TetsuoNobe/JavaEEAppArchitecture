/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.command;

import java.sql.SQLException;
import example.controller.RequestContext;
import example.controller.ResponseContext;


/**
 *
 * @author TNOBE
 */

public abstract class Command {

         /**
	 * 業務処理を呼び出し、その結果を元に遷移先を返却する。
	 *
	 * @param requestContext
	 *            リクエストコンテキスト
	 * @return responseContext
	 */
	public ResponseContext execute(RequestContext requestContext) {
               ResponseContext responseContext = null;
		try {
			// リクエストに対するCommandごとの個別の処理
			responseContext = processRequest(requestContext);                       
                        return  responseContext;
    
		} catch (SQLException  e) {
			// 例外のスタック・トレースを出力
			// （実際はログ・ファイルなどに出力）
			e.printStackTrace();

			// SQLやJNDIの例外が発生した場合、エラーメッセージをセットしてエラー・ページに遷移
                         responseContext = new ResponseContext();
                         responseContext.setRequestContext(requestContext);
                         responseContext.setNextPage("/error.jsp");
                         responseContext.setErrorMessage("DBアクセス中に例外が発生しました。" + "\n" + e.getMessage());
			 return responseContext;
		}
	}
        
        // リクエストに対するCommandごとの個別の処理を実行
	protected abstract ResponseContext processRequest(RequestContext requestContext) throws SQLException;

}
