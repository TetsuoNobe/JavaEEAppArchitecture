/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.command;


import example.service.CustomerService;

/**
 *
 * @author TNOBE
 */
public  class CommandFactory {
    
    /**
     * 指定された文字列に該当するCommandクラスのオブジェクトを取得する。
     *
     * @param actionName アクション名
     * @param service
     * @return Commandオブジェクト<br>
     * 該当するCommandクラスが存在しない場合、NULL
     */
    public static Command getInstance(String actionName,CustomerService service) {

        if (actionName == null) {
            return new IndexCommand();
        }

        switch (actionName) {
           
            case "findByName":
                return new FindByNameCommand(service);
            case "findAll":
                return new FindAllCommand(service);
            case "createForm":
                return new CreateFormCommand();
            case "create":
                return new CreateCommand(service);
            case "updateForm":
                return new UpdateFormCommand(service);    
            case "update":
                return new UpateCommand(service);
            case "deleteConfirm":
                return new DeleteConfirmCommand(service);
            case "delete":
                return new DeleteCommand(service);
            default:
                return new IndexCommand();
        }
    }
}
