package example.service;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import example.dao.CustomerDAO;
import example.entity.Customer;

/**
 * 顧客情報操作ビジネスロジック。
 *
 * @author tnobe
 *
 */
@Dependent
public class CustomerService implements Serializable {
        
        @Inject
	private  CustomerDAO dao; 

	/**
	 * 顧客情報リストを取得する。
	 *
	 * @return 検索結果<br>
	 *         該当する顧客情報が存在しない場合、NULL
	 * @throws SQLException
	 *             SQL例外が発生した場合
	 *
	 */
	public List<Customer> getCustomers() throws SQLException {
		return dao.findAll();
	}

	/**
	 * 顧客情報を登録する。
	 *
	 * @param customer
	 *            顧客情報
	 * @return 登録に成功した場合はTrue<br>
	 *         登録に失敗した場合はFalse
	 * @throws SQLException
	 *             SQL例外が発生した場合
	 */
	public boolean create(Customer customer) throws SQLException {
		return dao.create(customer);
	}

	/**
	 * 顧客情報を変更する。
	 *
	 * @param customer
	 *            顧客情報
	 * @return 変更に成功した場合はTrue<br>
	 *         変更に失敗した場合はFalse
	 * @throws SQLException
	 *             SQL例外が発生した場合
	 */
	public boolean update(Customer customer) throws SQLException {
		return dao.merge(customer);
	}

	/**
	 * 顧客情報を削除する。
	 *
	 * @param customer
	 *            顧客情報
	 * @return 削除に成功した場合はTrue<br>
	 *         削除に失敗した場合はFalse
	 * @throws SQLException
	 *             SQL例外が発生した場合
	 */
	public boolean delete(Customer customer) throws SQLException {
		return dao.remove(customer);
	}

	/**
	 * 顧客情報を取得する。
	 *
	 * @param customerId
	 *            顧客ID
	 * @return 顧客情報 該当する顧客情報が存在しない場合、NULL
	 * @throws SQLException
	 *             SQL例外が発生した場合
	 */
	public Customer find(String customerId) throws SQLException {
		return dao.findById(customerId);
	}
        
        /**
	 * 顧客情報を取得する。
	 *
	 * @param name
	 *            氏名
	 * @return 顧客情報 該当する顧客情報が存在しない場合、NULL
	 * @throws SQLException
	 *             SQL例外が発生した場合
	 */
	public List<Customer> findByName(String name) throws SQLException {
		return dao.findByName(name);
	}
}
