/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.enterprise.context.Dependent;
import javax.sql.DataSource;
import example.entity.Customer;

/**
 *
 * @author TNOBE
 */
@Dependent
public class CustomerDAO implements Serializable {

    @Resource(name = "jdbc/oracle")
    DataSource ds;

// 顧客情報テーブルを全件検索する
    public List<Customer> findAll() throws SQLException {

        // CUSTOMERテーブルを全件検索するSQL文
        String sql = "SELECT ID "
                + "     , NAME "
                + "     , ADDRESS "
                + "     , TELNO "
                + "  FROM CUSTOMER"
                + "  ORDER BY TO_NUMBER(ID)";

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {

            // CustomerオブジェクトのListを生成
            List<Customer> customerList = new ArrayList<>();

            // 検索結果をループしてCustomerオブジェクトのListに格納
            while (rs.next()) {
                // Customerオブジェクトを生成
                Customer customer = createCustomer(rs);

                // CustomerオブジェクトのListに格納
                customerList.add(customer);
            }

            // CustomerオブジェクトのListを返す
            return customerList;
        }
    }

    // CUSTOMERテーブルを主キー検索する
    public Customer findById(String customerId) throws SQLException {

        // CUSTOMERテーブルを顧客IDの条件で検索するSQL文
        String sql = "SELECT ID "
                + "     , NAME "
                + "     , ADDRESS "
                + "     , TELNO "
                + "  FROM CUSTOMER"
                + "  WHERE ID = ?";
              

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            // プレース・ホルダに値を設定
            ps.setString(1, customerId);

            try (ResultSet rs = ps.executeQuery()) {
                // 検索結果が存在しない場合、NULLを返す
                if (!rs.next()) {
                    return null;
                }

                // Customerオブジェクトを生成
                Customer customer = createCustomer(rs);

                // Customerを返す
                return customer;
            }
        }
    }

    // CUSTOMERテーブルを氏名で検索する
    public List<Customer> findByName(String name) throws SQLException {

        // CUSTOMERテーブルを顧客IDの条件で検索するSQL文
        String sql = "SELECT ID "
                + "     , NAME "
                + "     , ADDRESS "
                + "     , TELNO "
                + "  FROM CUSTOMER"
                + "  WHERE NAME LIKE ?";

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {
            StringBuilder sb = new StringBuilder();
            sb.append("%");
            if (!(name == null || name.equals(""))) {
                sb.append(name).append("%");
            }
            // プレース・ホルダに値を設定
            ps.setString(1, sb.toString());
            // CustomerオブジェクトのListを生成
            List<Customer> customerList = new ArrayList<>();

            try (ResultSet rs = ps.executeQuery()) {

                // 検索結果をループしてCustomerオブジェクトのListに格納
                while (rs.next()) {
                    // Customerオブジェクトを生成
                    Customer customer = createCustomer(rs);

                    // CustomerオブジェクトのListに格納
                    customerList.add(customer);
                }
            }

            // CustomerオブジェクトのListを返す
            return customerList;
        }
    }

    // CUSTOMERテーブルに顧客情報を新規登録する
    public boolean create(Customer customer) throws SQLException {

        // CUSTOMERテーブルにデータを追加するSQL文
        String sql = "INSERT INTO CUSTOMER"
                + "          ( ID "
                + "          , NAME "
                + "          , ADDRESS "
                + "          , TELNO "
                + " ) VALUES ( ?, ?, ?, ?)";

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            // プレース・ホルダに値を設定
            ps.setString(1, customer.getId());
            ps.setString(2, customer.getName());
            ps.setString(3, customer.getAddress());
            ps.setString(4, customer.getTelno());

            // SQL文を実行
            int affectedRows = ps.executeUpdate();
            boolean insResult = affectedRows == 1;

            // 実行結果を返す
            return insResult;
        }
    }

    // CUSTOMERテーブルに顧客情報を更新する
    public boolean merge(Customer customer) throws SQLException {

        // INSERT_INFOテーブルのデータを更新するSQL文
        String sql = "UPDATE CUSTOMER "
                + "   SET NAME = ?"
                + "     , ADDRESS = ? "
                + "     , TELNO = ? "
                + " WHERE ID = ? ";

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            // プレース・ホルダに値を設定
            ps.setString(1, customer.getName());
            ps.setString(2, customer.getAddress());
            ps.setString(3, customer.getTelno());
            ps.setString(4, customer.getId());

            // SQL文を実行
            int affectedRows = ps.executeUpdate();
            boolean updResult = affectedRows == 1;

            // 実行結果を返す
            return updResult;
        }
    }

    // 顧客情報テーブルから顧客情報を削除する
    public boolean remove(Customer customer) throws SQLException {

        // INVENTORY_INFOテーブルからデータを削除するSQL文
        String sql = "DELETE FROM CUSTOMER "
                + "      WHERE ID = ?";

        // データソースを取得
        //DataSource ds = DataSourceSupplier.getDataSource();
        try (Connection con = ds.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            // プレース・ホルダに値を設定
            ps.setString(1, customer.getId());

            // SQL文を実行
            int affectedRows = ps.executeUpdate();
            boolean delResult = affectedRows == 1;

            // 実行結果を返す
            return delResult;
        }
    }

    // ResultSetからCustomerオブジェクトを生成する
    private Customer createCustomer(ResultSet rs) throws SQLException {

        Customer customer = new Customer();
        customer.setId(rs.getString("ID"));
        customer.setName(rs.getString("NAME"));
        customer.setAddress(rs.getString("ADDRESS"));
        customer.setTelno(rs.getString("TELNO"));

        return customer;
    }
}
