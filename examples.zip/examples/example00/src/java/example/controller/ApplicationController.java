/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.controller;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import example.command.Command;
import example.command.CommandFactory;
import example.service.CustomerService;

/**
 *
 * @author TNOBE
 */
@SessionScoped
public abstract class ApplicationController implements Serializable {
    
    @Inject
    CustomerService  service;
    
      
   public ResponseContext  handleRequest(RequestContext requestContext) {
        Command command = CommandFactory.getInstance(requestContext.getAction(),service);
        ResponseContext responseContext = command.execute(requestContext);
        
        return  responseContext;
    } 
  
}
