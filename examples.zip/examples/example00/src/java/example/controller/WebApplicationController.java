/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.controller;

import java.io.IOException;
import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author TNOBE
 */
@SessionScoped
public class WebApplicationController extends ApplicationController implements Serializable {
    
    
     public ResponseContext  handleWebRequest(HttpServletRequest request) {
        // Context Objectを作成
        RequestContext requestContext = getRequestContext(request); 
        // リクエスト処理
        return  super.handleRequest(requestContext);
    } 
    
    public void dispatchView(HttpServletRequest request, HttpServletResponse response, ResponseContext responseContext) throws ServletException, IOException {
        request.setAttribute("resctx", responseContext);
        request.getRequestDispatcher(responseContext.getNextPage()).forward(request, response);
         
    }
    
    private RequestContext  getRequestContext(HttpServletRequest request) {
       RequestContext requestContext = new RequestContext();
       requestContext.setAction(request.getParameter("action"));
       requestContext.setId(request.getParameter("id"));
       requestContext.setName(request.getParameter("name"));
       requestContext.setAddress(request.getParameter("address"));
       requestContext.setTelno(request.getParameter("telno"));
       return requestContext;
   } 
    
}
