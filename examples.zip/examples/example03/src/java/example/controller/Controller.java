/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.controller;


import example.entity.Customer;
import example.service.CustomerService;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import javax.inject.Inject;

/**
 *
 * @author TNOBE
 */
@Named(value = "controller")
@SessionScoped
public class Controller implements Serializable {
    
    private String action;
    private String id;
    private String name;
    private String address;
    private String telno;

    private List<Customer> customerList;
    private Customer customer;
    private String errorMessage;
    

    @Inject
    CustomerService service;

    /**
     * Creates a new instance of Controller
     */
    public Controller() {
        
    }

    public String findAll() {
        this.action = "findAll";
        try {
           customerList = service.getCustomers();
           return "list";
        }
        catch (SQLException e) {
            this.errorMessage = e.getMessage();
            return "error";
        }
       
    }
    
    public String findByName() {
        this.action = "findName";
        try {
           customerList = service.findByName(this.name);
           if (customerList.isEmpty()) {
               this.errorMessage = "該当顧客なし";
               return "error";
           }
           return "list";
        }
        catch (SQLException e) {
            this.errorMessage = e.getMessage();
            return "error";
        }
    }
    
    public String createForm() {
        clearFields();
        this.action = "createForm";
        
         return "createForm";
        
    }
    
    public String create() {
        this.action = "create";
        Customer cust = new Customer(this.id,this.name,this.address,this.telno);
        try {
           boolean success =  service.create(cust);
           if (!success) {
               this.errorMessage = "新規作成失敗";
               return "error";
           }
           clearFields();
           return "index";
        }
        catch (SQLException e) {
            this.errorMessage = e.getMessage();
            return "error";
        }
    }
    
    public String  updateForm() {
           return updateForm(this.id);
    }

    public String updateForm(String id) {
        this.action = "updateForm";
         try {
           Customer cust =  service.find(id);
           if (cust == null) {
               this.errorMessage = "該当顧客なし";
               return "error";
           }
           this.id = cust.getId();
           this.name = cust.getName();
           this.address = cust.getAddress();
           this.telno = cust.getTelno();
           return "updateForm";
        }
        catch (SQLException e) {
            this.errorMessage = e.getMessage();
            return "error";
        }
    }

    public String update() {
        this.action = "update";
        Customer cust = new Customer(this.id,this.name,this.address,this.telno);
         try {
           boolean success =  service.update(cust);
           if (!success) {
               this.errorMessage = "更新失敗";
               return "error";
           }
           clearFields();
           return "index";
        }
        catch (SQLException e) {
            this.errorMessage = e.getMessage();
            return "error";
        }
    }
    
    public String deleteConfirm() {
         this.action = "deleteConfirm";
         try {
           Customer cust =  service.find(id);
           if (cust == null) {
               this.errorMessage = "該当顧客なし";
               return "error";
           }
           this.id = cust.getId();
           this.name = cust.getName();
           this.address = cust.getAddress();
           this.telno = cust.getTelno();
           return "deleteConfirm";
        }
        catch (SQLException e) {
            this.errorMessage = e.getMessage();
            return "error";
        }
    }

    public String deleteConfirm(String id) {
        this.id = id;
        return deleteConfirm();
    }

    public String delete() {
        this.action = "delete";
        Customer cust = new Customer(this.id,this.name,this.address,this.telno);
         try {
           boolean success =  service.delete(cust);
           if (!success) {
               this.errorMessage = "削除失敗";
               return "error";
           }
           clearFields();
           return "index";
        }
        catch (SQLException e) {
            this.errorMessage = e.getMessage();
            return "error";
        }
    }
    
    
    public String toIndex() {    
        clearFields();
        return "index";
    }  

    private void clearFields() {
        this.action=null;
        this.id=null;
        this.name=null;
        this.address=null;
        this.telno=null;
    }
    

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTelno() {
        return telno;
    }

    public void setTelno(String telno) {
        this.telno = telno;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    
    

}
