package example.service;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import javax.enterprise.context.Dependent;
import example.entity.Customer;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

/**
 * 顧客情報操作ビジネスロジック。
 *
 * @author tnobe
 *
 */

@Dependent
@Transactional
public class CustomerService implements Serializable {

    @PersistenceContext(name = "example03PSU")
    private EntityManager em;

    /**
     * 顧客情報リストを取得する。
     *
     * @return 検索結果<br>
     * 該当する顧客情報が存在しない場合、NULL
     * @throws SQLException SQL例外が発生した場合
     *
     */
    public List<Customer> getCustomers() throws SQLException {
        return em.createNamedQuery("Customer.findAll").getResultList();
    }

    /**
     * 顧客情報を登録する。
     *
     * @param customer 顧客情報
     * @return 登録に成功した場合はTrue<br>
     * 登録に失敗した場合はFalse
     * @throws SQLException SQL例外が発生した場合
     */
    public boolean create(Customer customer) throws SQLException {
            em.persist(customer);
            return true;
    }

    /**
     * 顧客情報を変更する。
     *
     * @param customer 顧客情報
     * @return 変更に成功した場合はTrue<br>
     * 変更に失敗した場合はFalse
     * @throws SQLException SQL例外が発生した場合
     */
    public boolean update(Customer customer) throws SQLException {
           em.merge(customer);
           return true;
    }

    /**
     * 顧客情報を削除する。
     *
     * @param customer 顧客情報
     * @return 削除に成功した場合はTrue<br>
     * 削除に失敗した場合はFalse
     * @throws SQLException SQL例外が発生した場合
     */
    public boolean delete(Customer customer) throws SQLException {
        em.remove(em.merge(customer));
        return true;
    }

    /**
     * 顧客情報を取得する。
     *
     * @param customerId 顧客ID
     * @return 顧客情報 該当する顧客情報が存在しない場合、NULL
     * @throws SQLException SQL例外が発生した場合
     */
    public Customer find(String customerId) throws SQLException {
        return em.find(Customer.class, customerId);
    }

    /**
     * 顧客情報を取得する。
     *
     * @param name 氏名
     * @return 顧客情報 該当する顧客情報が存在しない場合、NULL
     * @throws SQLException SQL例外が発生した場合
     */
    public List<Customer> findByName(String name) throws SQLException {
        StringBuilder sb = new StringBuilder();
        sb.append("%");
        if (!(name == null || name.equals(""))) {
            sb.append(name).append("%");
        }
        Query query = em.createNamedQuery("Customer.findByName");
        query.setParameter("name", sb.toString());
        return query.getResultList();
    }

    
}
