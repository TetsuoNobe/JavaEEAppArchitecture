/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.command;

import java.sql.SQLException;
import example.controller.RequestContext;
import example.controller.ResponseContext;
import example.entity.Customer;
import example.service.CustomerService;

/**
 *
 * @author TNOBE
 */
public class UpateCommand    extends Command{
     private CustomerService service;

    public UpateCommand(CustomerService service) {
        this.service = service;
    }
    @Override
    protected ResponseContext processRequest(RequestContext requestContext) throws SQLException {
           Customer customer = new Customer(requestContext.getId(),requestContext.getName(),requestContext.getAddress(),requestContext.getTelno());
           boolean result = service.update(customer);
           ResponseContext responseContext = new ResponseContext();
           responseContext.setCustomer(customer);
           responseContext.setSuccess(result);
           responseContext.setNextPage("index");
           return responseContext;
    }
    
}
