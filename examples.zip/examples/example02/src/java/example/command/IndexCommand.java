/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.command;

import java.sql.SQLException;
import example.controller.RequestContext;
import example.controller.ResponseContext;

/**
 *
 * @author TNOBE
 */
public class IndexCommand  extends Command{

    @Override
    protected ResponseContext processRequest(RequestContext requestContext) throws SQLException {
               ResponseContext responseContext = new ResponseContext();
               responseContext.setNextPage("index");
               return responseContext;
    }
    
}
