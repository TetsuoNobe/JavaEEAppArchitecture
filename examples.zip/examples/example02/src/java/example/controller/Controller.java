/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.controller;

import example.command.Command;
import example.command.CommandFactory;
import example.service.CustomerService;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.inject.Inject;

/**
 *
 * @author TNOBE
 */
@Named(value = "controller")
@SessionScoped
public class Controller implements Serializable {
    
    private String action;
    private String id;
    private String name;
    private String address;
    private String telno;

    private ResponseContext responseContext;
    

    @Inject
    CustomerService service;

    /**
     * Creates a new instance of Controller
     */
    public Controller() {
        
    }

    public String findAll() {
        ResponseContext resContext = executeCommand("findAll");
        this.responseContext = resContext;
        String nextPage = resContext.getNextPage();
        return nextPage;
    }

    public String findByName() {
        ResponseContext resContext = executeCommand("findByName");
        this.responseContext = resContext;
        String nextPage = resContext.getNextPage();
        return nextPage;
    }

    public String createForm() {
        clearFields();
        ResponseContext resContext = executeCommand("createForm");
        this.responseContext = resContext;
        String nextPage = resContext.getNextPage();
        return nextPage;
    }

    public String create() {
        ResponseContext resContext = executeCommand("create");
        String nextPage = resContext.getNextPage();
        clearFields();
        return nextPage;
    }

    public String updateForm() {
        ResponseContext resContext = executeCommand("updateForm");
        this.responseContext = resContext;
        if (responseContext.getCustomer() != null) {
           setFields(responseContext);
        }
        String nextPage = resContext.getNextPage();
        return nextPage;
    }

    public String updateForm(String id) {
        this.id = id;
        return updateForm();
    }

    public String update() {
        ResponseContext resContext = executeCommand("update");
        String nextPage = resContext.getNextPage();
        clearFields();
        return nextPage;
    }

    public String deleteConfirm() {
        ResponseContext resContext = executeCommand("deleteConfirm");
        this.responseContext = resContext;
        String nextPage = resContext.getNextPage();
        return nextPage;
    }

    public String deleteConfirm(String id) {
        this.id = id;
        ResponseContext resContext = executeCommand("deleteConfirm");
        this.responseContext = resContext;
        String nextPage = resContext.getNextPage();
        return nextPage;
    }

    public String delete() {
        ResponseContext resContext = executeCommand("delete");
        String nextPage = resContext.getNextPage();
        clearFields();
        return nextPage;
    }

    public String toIndex() {
        ResponseContext resContext = executeCommand("index");
        String nextPage = resContext.getNextPage();
        clearFields();
        return nextPage;
    }

    private ResponseContext executeCommand(String action) {
        Command command = CommandFactory.getInstance(action, service);
        // Context Objectを作成
        RequestContext requestContext = getRequestContext(action);
        ResponseContext resContext = command.execute(requestContext);
        return resContext;
    }

  

    public ResponseContext getResponseContext() {
        return responseContext;
    }

    public void setResponseContext(ResponseContext responseContext) {
        this.responseContext = responseContext;
    }

    

    private RequestContext getRequestContext(String action) {
        RequestContext requestContext = new RequestContext();
        requestContext.setAction(action);
        requestContext.setId(this.id);
        requestContext.setName(this.name);
        requestContext.setAddress(this.address);
        requestContext.setTelno(this.telno);
        return requestContext;
    }

    private void clearFields() {
        this.id=null;
        this.name=null;
        this.address=null;
        this.telno=null;
        this.responseContext = null;
    }
    
    private void setFields(ResponseContext resCtx) {
        this.id=resCtx.getCustomer().getId();
        this.name=resCtx.getCustomer().getName();
        this.address=resCtx.getCustomer().getAddress();
        this.telno=resCtx.getCustomer().getTelno();
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTelno() {
        return telno;
    }

    public void setTelno(String telno) {
        this.telno = telno;
    }
    
    

}
